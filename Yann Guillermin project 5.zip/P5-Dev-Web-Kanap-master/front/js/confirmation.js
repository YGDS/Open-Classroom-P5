
//function to catch the reponse of the post request and displaying the order id in the right place

function displayID() {
    let orderConfirm = JSON.parse(localStorage.getItem("articleID"));
    document.getElementById("orderId").textContent = orderConfirm.orderId;
}


displayID();

// remove local storage
localStorage.removeItem("articleID");