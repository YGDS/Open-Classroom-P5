fetch("http://localhost:3000/api/products").then(function(res) {
    return res.json();
}).then(function(Article) {
    generate_cart(Article);
    //making sure to call the event function AFTER generating the cart page
    get_event(Article);
    edit_value(Article);
})



//generating user cart list

function generate_cart(Article) {
    let cart_list = JSON.parse(window.localStorage.getItem("user_cart"));
    const display_cart = document.getElementById("cart__items");

    for (let i = 0; i < cart_list.length; i++) {
  
        const articleElement = document.createElement("article");
        articleElement.setAttribute("class", "cart__item");
        articleElement.setAttribute("data-id", cart_list[i]._id);
        articleElement.setAttribute("data-color", cart_list[i].color);

        const picturediv = document.createElement("div");
        picturediv.setAttribute("class", "cart__item__img");
        
        const imageElement = document.createElement("img");
        imageElement.src = Article.find(Article => Article._id === `${cart_list[i]._id}`).imageUrl;
        imageElement.setAttribute("alt", "Photographie d'un canapé");
        picturediv.appendChild(imageElement);
        articleElement.appendChild(picturediv);


        const cart_item_content = document.createElement("div");
        cart_item_content.setAttribute("class", "cart__item__content");

        const cart_item_description = document.createElement("div");

        const titleElement = document.createElement("h2");
        titleElement.innerText = Article.find(Article => Article._id === `${cart_list[i]._id}`).name;
        cart_item_description.appendChild(titleElement);

        const colorElement = document.createElement("p");
        colorElement.innerText = cart_list[i].color;
        cart_item_description.appendChild(colorElement);

        const product_price_Element = document.createElement("p");
        product_price_Element.innerText = Article.find(Article => Article._id === `${cart_list[i]._id}`).price;
        cart_item_description.appendChild(product_price_Element);

        cart_item_content.appendChild(cart_item_description);
        

        const cart_item_settings = document.createElement("div");
        cart_item_settings.setAttribute("class", "cart__item__content__settings");

        const cart_item_quantity = document.createElement("div");
        cart_item_quantity.setAttribute("class", "cart__item__content__settings__quantity");

        const quantity_text = document.createElement("p");
        quantity_text.innerText = "Qté : ";
        cart_item_quantity.appendChild(quantity_text);

        const input_quantity = document.createElement("input");
        input_quantity.type = "number";
        input_quantity.setAttribute("class", "itemQuantity");
        input_quantity.setAttribute("name", "itemQuantity");
        input_quantity.setAttribute("min", "1");
        input_quantity.setAttribute("max", "100");
        input_quantity.setAttribute("value", cart_list[i].number);
        cart_item_quantity.appendChild(input_quantity);

        const delete_product = document.createElement("div");
        delete_product.setAttribute("class", "cart__item__content__settings__delete");

        const delete_btn = document.createElement("p");
        delete_btn.setAttribute("class", "deleteItem");
        delete_btn.innerText = "Supprimer";
        delete_product.appendChild(delete_btn);

        cart_item_settings.appendChild(cart_item_quantity);
        cart_item_settings.appendChild(delete_product);

        cart_item_content.appendChild(cart_item_settings);
        articleElement.appendChild(cart_item_content);
        display_cart.appendChild(articleElement);
    }
    refreshing_totcart(Article, cart_list);
}



//event function ot check wich btn got click and splice the item by it's id in the html collection

function get_event(Article) {
    const button_add = document.getElementsByClassName("deleteItem");
    let cart_list = JSON.parse(window.localStorage.getItem("user_cart"));
    for (let i = 0; i < button_add.length; i++) {
        button_add[i].addEventListener("click", function() {
            remove_indexitem(cart_list, i);
        });
    }
}

//refresh nb of item and total price when editing quantity

function edit_value(Article) {
    const edit_btn = document.getElementsByClassName("itemQuantity");
    let cart_list = JSON.parse(window.localStorage.getItem("user_cart"));
    for (let i = 0; i < edit_btn.length; i++) {
        edit_btn[i].addEventListener("change", function() {
            cart_list[i].number = edit_btn[i].value;
            window.localStorage.removeItem("user_cart");
            window.localStorage.setItem("user_cart", JSON.stringify(cart_list));
            let refresh = document.getElementsByClassName("cart__items");
            refreshing_totcart(Article, cart_list);
        });
    }
}

//created this function in case i need to delete an item in cart with other mean than the delete btn

function remove_indexitem(cart_list, index) {
    cart_list.splice(index, 1);
    window.localStorage.removeItem("user_cart");
    window.localStorage.setItem("user_cart", JSON.stringify(cart_list));
    document.getElementsByClassName("cart__item")[i].remove();
    refreshing_totcart(Article, cart_list);
}

function refreshing_totcart(Article, cart_list) {
    let quantity_value = document.getElementById("totalQuantity");
    quantity_value.innerText = get_all_quantity(cart_list);
    let full_price = document.getElementById("totalPrice");
    full_price.innerText = get_full_price(Article ,cart_list);
}

//function that check each price for product and multiply it by the number of product in the cart

function get_full_price(Article, cart_list) {
    
    let add = 0;
    let res = 0;
    for (let i=0; i< cart_list.length; i++) {
        add = Number(Article.find(Article => Article._id === `${cart_list[i]._id}`).price) * cart_list[i].number;
        res = res + add;
    }
    return res;
}

//function to sum up all product in the cart list

function get_all_quantity(cart_list) {
    let res = 0;
    for (let i = 0; i < cart_list.length; i++) {
        res = res + Number(cart_list[i].number);
    }
    return res;
}

//function with regex to check good input in form

document.getElementById("email").addEventListener('input', () => {
    let validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+\.[a-zA-Z]*$/;
    let input = document.getElementById("email");
    if (input.value.match(validRegex)) {
        let alert_msg = document.getElementById("emailErrorMsg");
        alert_msg.innerText = "";
    } else {
        let alert_msg = document.getElementById("emailErrorMsg");
        alert_msg.innerText = "Please enter a valid email";
    }
})


document.getElementById("firstName").addEventListener('input', () => {
    let validRegex = /^([a-zA-Z])*$/;
    let input = document.getElementById("firstName");
    if (input.value.match(validRegex)) {
        let alert_msg = document.getElementById("firstNameErrorMsg");
        alert_msg.innerText = "";
    } else {
        let alert_msg = document.getElementById("firstNameErrorMsg");
        alert_msg.innerText = "Please enter a valid first name";
    }
})

document.getElementById("lastName").addEventListener('input', () => {
    let validRegex = /^([a-zA-Z])*$/;
    let input = document.getElementById("lastName");
    if (input.value.match(validRegex)) {
        let alert_msg = document.getElementById("lastNameErrorMsg");
        alert_msg.innerText = "";
    } else {
        let alert_msg = document.getElementById("lastNameErrorMsg");
        alert_msg.innerText = "Please enter a valid last name";
    }
})

document.getElementById("address").addEventListener('input', () => {
    let validRegex = /^([a-zA-Z0-9.'-, ])*$/;
    let input = document.getElementById("address");
    if (input.value.match(validRegex)) {
        let alert_msg = document.getElementById("addressErrorMsg");
        alert_msg.innerText = "";
    } else {
        let alert_msg = document.getElementById("addressErrorMsg");
        alert_msg.innerText = "Please enter a valid address";
    }
})


document.getElementById("city").addEventListener('input', () => {
    let validRegex = /^([a-zA-Z.'-, ])*$/;
    let input = document.getElementById("city");
    if (input.value.match(validRegex)) {
        let alert_msg = document.getElementById("cityErrorMsg");
        alert_msg.innerText = "";
    } else {
        let alert_msg = document.getElementById("cityErrorMsg");
        alert_msg.innerText = "Please enter a valid city";
    }
})

//insert all id in an array and create an object with good value before sending both as an object to add_comm

function set_data_form() {
    let products = [];
    let cart_list = JSON.parse(window.localStorage.getItem("user_cart"));

    for (let i=0; i<cart_list.length; i++) {
        products.push(cart_list[i]._id);
    }

    let contact = {
        firstName: document.getElementById("firstName").value,
        lastName: document.getElementById("lastName").value,
        address: document.getElementById("address").value,
        city: document.getElementById("city").value,
        email: document.getElementById("email").value,
    }
    add_comm({products, contact});
}

//generating a post request and checking the json formated response  before save the id and sending to confirmation page

function add_comm(obj) {
    fetch("http://localhost:3000/api/products/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(obj),

    }).then((response) => {
        return response.json();
    }).then((response) => {
        localStorage.setItem("articleID", JSON.stringify(response));
        location.assign("confirmation.html")
    })
    .catch((error) => {
        alert("Une erreur est survenue", error);
    });
}

//init the button to send the form

let cart_Form = document.getElementById("order");

cart_Form.addEventListener("click", (event) => {
    event.preventDefault();
    set_data_form();
});

